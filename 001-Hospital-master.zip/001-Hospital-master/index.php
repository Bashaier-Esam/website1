﻿<?php
include"connect.php";
include"includes/header.php" ?>


<div class="col-md-12" style="padding-top:25px;">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"  style="width:75%; margin:0 auto;" >
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <?php
    $test2 = $db->query("SELECT*FROM index_carousel ");
    $test2->execute();
    $resultat2 = $test2->fetch();
            ?>
            <div class="item active">
                <img src="<?php echo $resultat2['link']; ?>" alt="..." width="100%" >
                <div class="carousel-caption">
                    ...
                </div>
            </div>
            <?php

            $test1 = $db->query("SELECT*FROM index_carousel ORDER BY id DESC LIMIT 100 ");
            $test1->execute();
            while($resultat1 = $test1->fetch()){
            ?>
            <div class="item">
                <img src="<?php echo $resultat1['link']; ?>" alt="..." width="100%" >
                <div class="carousel-caption">
                    ...
                </div>
            </div>
            <?php
            }
            ?>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>







<div class="col-md-12" style="padding-top:25px;">
    <h3>LATEST NEWS MADINAH</h3>
</div>
<div class="row">
   <div class="col-md-4"   style="padding-top:25px;">
        <div class="card" >
            <img class="img-responsive" src="files/images/ee.jpg" alt="Card image cap">
            <div class="card-block">
                <h4 class="card-title">Executive Committee
                 </h4><br>
               <!-- <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>-->
                <a href="excom" class="btn btn-primary">More Details</a>
            </div>
        </div>
    </div>
<?php
$statement=$db->prepare("SELECT * FROM news_picture");
$statement->execute();
$results=$statement->fetchAll(PDO::FETCH_ASSOC);



$test3 = $db->query("SELECT*FROM news ORDER BY id LIMIT 2 ");
$test3->execute();
while($resultat3 = $test3->fetch()){
    $lenght=30;
    $description=$resultat3['text'];
    $new_description=substr($description,0,$lenght)."...";




    $nid =$resultat3['id'];
    $results1 = array_filter($results, function($arrs)  use ($nid) {

        return $arrs['news_id'] == $nid;
    });

    array_values($results1)[0]['link'];
?>


<div class="col-md-4"  style="padding-top:25px;">

    <div class="card" >
        <img class="img-responsive" src="<?php echo array_values($results1)[0]['link'];?>" alt="Card image cap">
        <div class="card-block">
            <h4 class="card-title"><?php echo $resultat3['title']; ?></h4>
<!--            <p class="card-text"><?php echo $new_description; ?></p>-->

            <a href="spnews.php?id=<?php echo $resultat3['id']; ?>" class="btn btn-primary">Go somewhere</a>
        </div>
    </div>
</div>
<?php
} ?>
</div>
<div class="row">
    <?php

    $test5 = $db->query("SELECT*FROM index_video ORDER BY id LIMIT 1 ");
    $test5->execute();
    $resultat5 = $test5->fetch();
    ?>
    <div class="col-md-8" style="padding-top:25px;">
        <div class="col-8">
            <div class="embed-responsive embed-responsive-16by9">
                <video id="vidH"  width="320" height="240" controls>
                    <source src="<?php echo $resultat5['vid']; ?>" type="video/mp4">
                </video>
            </div>
        </div>
    </div>
    <?php

    $test4  = $db->query("SELECT * FROM events ORDER BY id LIMIT 1");
    $test4->execute();
    $resultat4 = $test4->fetch();
    $lenght = 80;
    $description1=$resultat4['text'];
    $new_description1=substr($description1,0,$lenght)."...";
    ?>

    <div class="col-md-4" style="padding-top:25px;">
        <div class="card"  id="cardvid">
            <img class="img-responsive"  src="<?php echo $resultat4['img']; ?>" alt="Card image cap">
            <div class="card-block">
                <h4 class="card-title"><?php echo $resultat4['title']; ?></h4>
<!--                <p class="card-text"><?php echo $new_description1; ?></p>-->
                <br>
                <a href="spnews.php?id=<?php echo $resultat4['id']; ?>" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <br><br>
</div>




<?php include"includes/footer.php" ?>
