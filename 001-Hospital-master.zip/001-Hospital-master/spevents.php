﻿<?php
include"connect.php";
include"includes/header.php" ?>

<style>
.thumbnail {
    max-height: 324px;
}
</style>

        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a href="media" class="list-group-item active ">Media </a>
                <a href="news" class="list-group-item list-group-item-action">News</a>
                <a href="events" class="list-group-item list-group-item-action">Events</a>
            </div>
        </div>
        <div class="col-md-9" style="padding-top:25px;">
 <?php
  $id=$_GET['id'];
 $test1 = $db->query("SELECT*FROM events WHERE id=$id");
$test1->execute();
$resultat1 = $test1->fetch();
?>
            <div class="row">


                <h3><?php echo $resultat1['title']; ?> </h3><br>
                <div class="col-md-12" ></div>

                <div class="col-md-12">
                    <p class="text-justify"><?php echo $resultat1['text']; ?> </p>

                </div>

 <div class="row">
    <div class="col-md-6">
      <div class="thumbnail">
          <img src="<?php echo $resultat1['img']; ?>" alt="Lights" style="width:100%">
      </div>
    </div>

<?php
 $id=$_GET['id'];
 $test2 = $db->query("SELECT*FROM events_id WHERE events_id=$id");
$test2->execute();
while($resultat2 = $test2->fetch()){

?>
    <div class="col-md-6">
      <div class="thumbnail">
          <img src="<?php echo $resultat2['link']; ?>" alt="Lights" style="width:100%">
      </div>
    </div>


<?php
}
?></div>

            </div>
        </div>

        <div class="col-md-12">
            <br><br>
        </div>



        <?php include"includes/footer.php" ?>