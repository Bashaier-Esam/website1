﻿
<?php
include"connect.php";
 include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
          <a  class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>


    </div>
</div>
<div class="col-md-9">
    <div class="table-responsive">
        <table class="table">
<?php 
$id=$_GET['id'];
 $test1 = $db->query("SELECT*FROM training_courses WHERE id=$id ");
$test1->execute();
 $resultat1 = $test1->fetch();
?>
            <h3> Course Deatils</h3>

            <tr>
                <td class="success" ><strong>COURSE TITLE </strong></td>
                <td ><?php echo $resultat1['title']; ?></td>
                <td class="success"><strong>PRESENTED BY</strong></td>
                <td ><?php echo $resultat1['presented_by']; ?></td>


            </tr>

            <tr>
                <td class="success"><strong>DATE-FROM</strong></td>
                <td ><?php echo $resultat1['date_from']; ?></td>
                <td class="success"><strong>DATE-TO</strong></td>
                <td ><?php echo $resultat1['date_to']; ?></td>

            </tr>
            <tr>
                <td class="success"><strong>TIME-FROM</strong> </td>
                <td ><?php echo $resultat1['time_from']; ?></td>
                <td class="success"><strong>TIME-TO</strong></td>
                <td ><?php echo $resultat1['time_to']; ?></td>

            </tr>
            <tr>
                <td class="success" ><strong>PLACE</strong> </td>
                <td ><?php echo $resultat1['place']; ?> </td>
                <td  class="success"><Strong>LANGUGE</strong></td>
                <td ><?php echo $resultat1['language']; ?></td>
            </tr>
        </table>
    </div>

    <h3>Course Presentaion</h3><br>

   
 <li class="list-group-item ">
    <a href="<?php echo $resultat1['link']; ?>" >
        <img border="0" src="<?php echo $resultat1['link']; ?>" alt="Click here" width="104" height="142">
  </a></li>




</div>

<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>