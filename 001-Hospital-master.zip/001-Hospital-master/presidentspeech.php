﻿<?php include"includes/header.php" ?>

				<div class="col-md-3" style="padding-top:25px;">
					<div class="list-group">
						<a href="#" class="list-group-item active ">About us </a>
						<a href="aboutus" class="list-group-item list-group-item-action">Introduction</a>
						<a href="PresidentSpeech" class="list-group-item list-group-item-action"> President Letter</a>
                          <a href="ceoSpeech" class="list-group-item list-group-item-action">CEO Letter</a>
						<a href="missionVision" class="list-group-item list-group-item-action">Mission & Vision</a>

					</div>
				</div>
				<div class="col-md-9">
				<div class="row">

				<h3>President Letter </h3><br>

					<div class="col-md-6">
					 <p class="text-justify">Middle East Healthcare Company Middleompany Middle East Hompany Middle Eompany Middle East Healtompany Middle East Healtast Healtompany Middle East Healtompany Middle East Healtealtompany Middle East Healtompany Middle East Healt East Healthcare CompanyMiddle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates </p>

					</div>

					<div class="col-md-3">

					<img class="card-img-left" src="files/images/002.jpg" alt="president" style="width:320px;height:250px;">
					</div>



				<div class="col-md-12">
				 <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>
					</div>


				</div>

			</div>

	  <div class="col-md-12">
	 <br><br>
	  </div>


      <?php include"includes/footer.php" ?>