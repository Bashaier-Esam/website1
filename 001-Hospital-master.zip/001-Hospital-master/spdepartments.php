﻿<?php
include"connect.php";
include"includes/header.php" ?>
<?php
 $id=$_GET['id'];
 $test1 = $db->query("SELECT * FROM departments WHERE id=$id");
$test1->execute();
$resultat1 = $test1->fetch();

?>

        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a class="list-group-item active ">Department & Centers </a>
                <a href="departments" class="list-group-item list-group-item-action">Mmedical Departments</a>
                <a href="centers" class="list-group-item list-group-item-action">Services Area</a>
            </div>
        </div>
        <div class="col-md-9"  style="padding-top:25px;">

            <div class="row">

                <div class="col-md-5" >
                    <div class="btn-group btn-group-justified" role="group" aria-label="...">
                        <div class="btn-group" role="group">

                            <a href="spdepartments.php?id=<?php echo $id ; ?>" class='btn btn-primary'>Services </a>
                        </div>
                        <div class="btn-group" role="group">

                           <a href="medicalstaffdep.php?id=<?php echo $id ?>" class='btn btn-primary'>Medical Staff</a>
                        </div>

                    </div>
                </div>

                <div class="col-md-12" style="padding-top:25px"></div>

                <h3><?= $resultat1['name'] ?> Services </h3>
                <p  style="white-space: pre-line;" class="text-justify">
                    <?= $resultat1['text'] ?>
                </p>

                <div class="row" style="padding-top:25px;">
                    <p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span> Head of Department Ext:<span> <?= $resultat1['ext'] ?></span></p>
                </div>

            </div>
        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>