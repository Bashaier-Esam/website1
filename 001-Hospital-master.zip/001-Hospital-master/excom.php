﻿<?php include"includes/header.php" ?>



<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active">About us </a>
        <a href="aboutus" class="list-group-item list-group-item-action">SGH Maddinah</a>
        <!--<a href="PresidentSpeech" class="list-group-item list-group-item-action"> President Letter</a>
<a href="ceoSpeech" class="list-group-item list-group-item-action">CEO Letter</a> -->
        <a href="missionVision" class="list-group-item list-group-item-action">Mission & Vision</a>
        <a href="excom" class="list-group-item list-group-item-action">Executive Committee</a>
    </div>
</div>
<div class="col-md-9">

    <div class="row">


        <h3>Executive Committee</h3><br>



        <div class="col-md-12">
            <table class="table">
                <thead class="thead-default">
                    <tr>
                        <th>Name</th>
                        <th>Postion</th>
                        <th>Email</th>
                        <th>Ext</th>
                    </tr>
                </thead>
               <tbody>
                    <tr>
                        <th scope="row"> Dr Ramez Alawdy</th>
                        <td>Chief Executive</td>
                        <td>Ceo.med@sghgroup.net</td>
                        <td>5001/5002</td>
                    </tr>
                    <tr>
                        <th scope="row">Dr Mahmoud Asaad</th>
                        <td>Medical Director</td>
                        <td>Cmo.med@sghgroup.net</td>
                        <td>6881</td>
                    </tr>
                    <tr>
                        <th scope="row">Mr Mohammed Rizwan</th>
                        <td>HR Manager</td>
                        <td>Hr1.med@sghgroup.net</td>
                        <td>6390</td>
                    </tr>
                    <tr>
                        <th scope="row">Mr Shauwkat Khan</th>
                        <td>IT Manager</td>
                        <td>It1.med@sghgroup.net</td>
                        <td>6363</td>
                    </tr>
                    <tr>
                        <th scope="row">Mr Rana Khurram</th>
                        <td>Finance Manager</td>
                        <td>Financecontrol1.med@sghgroup.et</td>
                        <td>6516</td>
                    </tr>
                    <tr>
                        <th scope="row">Mr Eslam Korany</th>
                        <td>MTM Managet</td>
                        <td>Mtm1.med@sghgroup.net</td>
                        <td>6569</td>
                    </tr>
                </tbody>
            </table>

        </div>

    </div>
</div>

<div class="col-md-12">
    <br><br>
     <br>
    <br>
    <br>
    <br>
    <br>
  
</div>


<?php include"includes/footer.php" ?>