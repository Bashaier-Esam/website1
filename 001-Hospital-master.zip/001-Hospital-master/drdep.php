﻿<?php
include"connect.php";
include"includes/header.php" ?>


   <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a class="list-group-item active ">Department & Centers </a>
                <a href="departments" class="list-group-item list-group-item-action">Mmedical Departments</a>
                <a href="centers" class="list-group-item list-group-item-action">Services Area</a>
            </div>
        </div>

    <div class="col-md-9" style="padding-top:25px;">
        <div class="row">
            <div class="col-md-5">
                <div class="btn-group btn-group-justified" role="group" aria-label="...">
                    <div class="btn-group" role="group">
                        <?php
    $id=$_GET['id'];
$test2 = $db->query("SELECT*FROM medical_staf WHERE id=$id ");
$test2->execute();
$resultat2 = $test2->fetch();
$idd=$resultat2['department_id'];
                    ?>
                            <a href="spdepartments.php?id=<?php echo $idd ; ?>" class='btn btn-primary'>Introduction</a>
                    </div>
                    <div class="btn-group" role="group">
                        <a href="medicalstaffdep.php?id=<?php echo $idd ; ?> " type="button" class='btn btn-primary'>Medical Staff  </a>
                    </div>

                </div>
            </div>


            <div class="col-md-12" style="padding-top:25px"></div>
            <div class="col-md-3">
                <img class="card-img-top" src="<?php echo $resultat2['img']; ?>" alt="doc" style="width:150px;height:170px;">
            </div>

            <div class="col-md-6">
                <h4> Doctor</h4>
                <hr noshade>
                <?php echo $resultat2['name']; ?><br>
                <?php echo $resultat2['departement_name']; ?><br>
                <?php echo $resultat2['email']; ?><br> Ext:
                <?php echo $resultat2['ext']; ?>
                <hr noshade>
            </div>

            <div class="col-md-12" style="padding-top:25px"></div>

            <div class="col-md-3">

                <h5>Education</h5>
            </div>

            <div class="col-md-6">
                <?php echo $resultat2['education']; ?>
            </div>

            <div class="col-md-12" style="padding-top:15px"></div>

            <!-- <div class="col-md-3">
<h5>Major Professional Experiences</h5>
</div>
<div class="col-md-6">
<?php echo $resultat2['experience']; ?>
</div>-->

<?php if(@pathinfo($resultat2['file'])['extension'] != null){ ?>
            <div class="col-md-3">
                <h5>Privilege</h5>
            </div>
            <div class="col-md-6 myli" style="padding-top:10px">
                <a href="<?php echo $resultat2['file']; ?>">Click here </a>
            </div>


<?php } ?>



        </div>
    </div>

    <div class="col-md-12">
        <br><br>
    </div>


    <?php include"includes/footer.php" ?>