﻿<?php include"includes/header.php" ?>

        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a href="tqm" class="list-group-item active ">Quality & Safety </a>
                <a href="procedur&policy" class="list-group-item list-group-item-action">Policies & procedures</a>
                <a href="clinicalprocedureguideline" class="list-group-item list-group-item-action">Clinical Procedures & Guidelines</a>
                <a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
                <a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
                <a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
            </div>
        </div>
        <div class="col-md-9">

            <div class="row">


                <h3>Introduction</h3><br>

                <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution. are in the various stages of execution.</p>


            </div>


        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>