﻿<?php
 include"connect.php";
include"includes/header.php" ?>


    <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a class="list-group-item active ">Department & Centers </a>
                <a href="departments" class="list-group-item list-group-item-action">Mmedical Departments</a>
                <a href="centers" class="list-group-item list-group-item-action">Services Area</a>
            </div>
        </div>
        <div class="col-md-9" >
            <div class="row">
            <?php
 $test2 = $db->query("SELECT*FROM departments ");
$test2->execute();
 while($resultat2 = $test2->fetch()){
 ?>

                 <div class="col-md-4" style="padding-top:25px">
            <div class="card-d" style="height:100%">
                <img class="img-responsive" src="<?php echo $resultat2['img']; ?>" alt="Card image cap">
                <div class="card-body">
                    <a href="spdepartments.php?id=<?php echo $resultat2['id']; ?>" class="list-group-item ">
                        <h4 class="card-title"><?php echo $resultat2['name']; ?></h4>
                    </a>
                </div>
            </div>
        </div>


            <?php
            }
            ?>

            </div>

        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>