<?php 
 session_start(); 
  if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>General Policies</h2>   
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                   <div class="panel panel-default">
                        <div class="panel-heading">
                             General Policies
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>File</th>
                                            <th> Option file </th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
<?php 
$id=$_GET['id'];
$test1 = $db->query("SELECT*FROM general_policies WHERE id=$id");
$test1->execute();
 while($resultat1 = $test1->fetch()){

?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $resultat1['title'] ; ?></td>
                                            <td>
                                            <?php   
                                            if(!empty($resultat1['file'])){
                                              ?>
                                          <a href="../<?php echo $resultat1['file']; ?>" download >
                                    <span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span>  </a> 
                                    <?php
                                  }else {
                                                 ?>
                                                 None
                                                 <?php
                                  }
                                  ?>
 </td>
 <td>
                                            <?php   
                                            if(!empty($resultat1['option_file'])){
                                              ?>
                                          <a href="../<?php echo $resultat1['option_file']; ?>" download >
                                    <span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span>  </a> 
                                    <?php
                                  }else {
                                                 ?>
                                                 None
                                                 <?php
                                  }
                                  ?>
 </td>
                                        </tr>
<?php 
}
?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        <a href="generalpolicies.php"><h4><i class="fa fa-arrow-left" aria-hidden="true"></i> Back </h4> </a>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
