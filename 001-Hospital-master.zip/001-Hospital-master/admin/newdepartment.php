<?php
session_start();
if (!isset($_SESSION['id']))
{
    header('Location:admin.php');
    exit;

}
include"connect.php";
$name= (isset($_POST['name'])) ? htmlspecialchars($_POST['name']) :'';
$text= (isset($_POST['text'])) ? htmlspecialchars($_POST['text']) :'';
$ext = (isset($_POST['ext'])) ? htmlspecialchars($_POST['ext']) :'';

$extensions_autorisees = array('.png','.PNG','.jpg','.JPG');

if (!empty($_POST)) {
    $file_name=$_FILES['img']['name'];
    $file_extension=strrchr($file_name,".");
    $file_tmp_name=$_FILES['img']['tmp_name'];
    $file_dest='files/images/'.$file_name;
    $file_dest1='../files/images/'.$file_name;
    if(in_array($file_extension,$extensions_autorisees) || empty($file_extension )){
        $q = "SELECT name FROM departments WHERE name = '$name'";

        $resultnname = $db->query($q)->fetchAll();

        if (count($resultnname) > 0) {
            $erreur2 = '<div class="alert alert-danger alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

    <strong>OPS!</strong>  This department is already exist
</div> ';
        }else{
            $req = $db->prepare('INSERT INTO departments (name,img,text,ext) VALUES(?,?,?,?)');
            $req->execute(array($name,$file_dest,$text,$ext));
            move_uploaded_file($file_tmp_name,$file_dest1);
        }


?>

<?php

    }else {
        $erreur2='Extension allowed .png,.PNG,jpg,JPG ';
    }

    $s = '<div class="alert alert-success alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

    <strong>Success!</strong> Done Added
</div>

<meta http-equiv="refresh" content="3;url=departments.php">';
}
?>
<?php
include"includes/header.php"
?>
<!-- /. NAV TOP  -->
<?php

    include"includes/navside.php"

?>

<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>New Department</h2>

            </div>
        </div>
        <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="panel panel-default">

                    <div class="panel-body">
                        <?php
    if(isset($erreur2)){

        echo $erreur2;
    }else{ echo @$s; }

                        ?>

                        <div class="table-responsive">

                            <form method="post" action="" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label style="color: #2c3e50"> Department Name:</label><br/>
                                    <input class="form-control" style="width:100%;" type="text" name="name" id="name" required>

                                </div>
                                <div class="form-group">
                                    <label style="color: #2c3e50">Select Picture:</label><br/>
                                    <input type="file" name="img" id="img" placeholder="download the picture" required>
                                </div>

                                <div class="form-group">
                                    <label style="color: #2c3e50"> Services:  </label><br/>
                                    <textarea class="form-control" style="width:100%;height:100px;" id="text" name="text"></textarea>
                                </div>
                                <div class="form-group">
                                                                  <label style="color: #2c3e50"> Department Head EXT</label><br/>
                                <input class="form-control" type="number" name="ext"><br/>
                                </div>


                                <input style="width:100px" type="submit" name="submit" value="Save">
                            </form>


                        </div>

                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>

        <!-- /. PAGE WRAPPER  -->
        <!-- /. WRAPPER  -->
        <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
        <!-- JQUERY SCRIPTS -->
        <script src="assets/js/jquery-1.10.2.js"></script>
        <!-- BOOTSTRAP SCRIPTS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- METISMENU SCRIPTS -->
        <script src="assets/js/jquery.metisMenu.js"></script>
        <!-- DATA TABLE SCRIPTS -->
        <script src="assets/js/dataTables/jquery.dataTables.js"></script>
        <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                $('#dataTables-example').dataTable();
            });

        </script>
        <!-- CUSTOM SCRIPTS -->
        <script src="assets/js/custom.js"></script>


        </body>

    </html>
