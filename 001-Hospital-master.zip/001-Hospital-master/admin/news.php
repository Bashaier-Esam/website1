<?php
session_start();
if (!isset($_SESSION['id']))
{
    header('Location:admin.php');
    exit;

}
include"connect.php";

if (isset($_GET['deletepicture']))
{
    $id=$_GET['deletepicture'];
    $reponse=$db->query("DELETE FROM news_picture WHERE id='$id'");
?>

<?php

}

//if (isset($_GET['delete']))
//{
//    $id=$_GET['delete'];
//    $reponse=$db->query("DELETE FROM news WHERE id='$id'");
//}


if (isset($_GET['s']) && isset($_GET['id'])){
    $id = $_GET['id'];
    $s  = $_GET['s'];
    $reponse=$db->query("UPDATE `news` SET `status` = '$s' WHERE `id` = '$id';");
}
?>
<?php
include"includes/header.php"
?>
<!-- /. NAV TOP  -->
<?php

    include"includes/navside.php"

?>

<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>News</h2>

            </div>
        </div>
        <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="panel panel-default">

                    <div class="panel-body">
                        <?php
    if (isset($_GET['delete']))
    {
        echo '<div class="alert alert-success alert-dismissable">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

  <strong>Success!</strong> Done Deleted
</div>';

        echo "<meta http-equiv='refresh' content='3;url=".basename($_SERVER['SCRIPT_NAME'])."'>";

    }
                        ?>

                        <?php
                        if (isset($_GET['deletepicture']))
                        {
                            echo '<div class="alert alert-success alert-dismissable">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

  <strong>Success!</strong> Done Deleted
</div>';

                            echo "<meta http-equiv='refresh' content='3;url=".basename($_SERVER['SCRIPT_NAME'])."'>";

                        }
                        ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Text</th>
                                        <th style="width: 350.021px;">img</th>
                                        <th>Add Picture </th>
<!--                                        <th> Delete </th>-->
                                        <th> Stop </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $test1 = $db->query("SELECT*FROM news");
                                    $test1->execute();
                                    while($resultat1 = $test1->fetch()){

                                    ?>
                                    <tr class="odd gradeX">
                                        <td><?php echo $resultat1['title'] ; ?></td>
                                        <td><?php echo $resultat1['text'] ; ?></td>

                                        <td>

                                                  <?php
                                        $id=$resultat1['id'];
                                        $test2 = $db->query("SELECT*FROM news_picture WHERE news_id=$id");
                                        $test2->execute();
                                        while($resultat2 = $test2->fetch()){

                                            ?>
                                            <li class="list-group-item">
                                                <a >
                                            <img src="../<?php echo $resultat2['link'] ; ?> "  alt="" height="150" height="150" />
                                                </a>
                                                <a class="badge badge-error" href="news.php?deletepicture=<?php echo $resultat2['id']; ?>">
                                                    <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                </a>

                                            </li>

                                            <?php
                                        }
                                            ?>
                                        </td>
                                        <td><a href="newspicture.php?id=<?php echo $resultat1['id']; ?> ">  <i class="fa fa-plus" aria-hidden="true"></i>       </td>
<!--
                                        <td class="center">
                                            <a href="#" class="btn btn-info" onclick="delConf('<?php echo $resultat1['id']; ?>')">
                                                <i class="fa fa-trash-o" aria-hidden="true"></i>
                                            </a>
                                        </td>
-->
                                        <td class="center">
                                                <div class="checkbox">
                                                  <input type="checkbox"  <?php echo ($resultat1['status'] == 0 ? 'checked' : ''); ?>  id="mycheck<?php echo $resultat1['id']; ?>" onclick="stop('<?php echo $resultat1['id']; ?>');">
                                                </div>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                        <a href="newnews.php"><h4><i class="fa fa-plus" aria-hidden="true"></i> Add a News </h4> </a>
                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>

        <!-- /. PAGE WRAPPER  -->
        <!-- /. WRAPPER  -->
        <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
        <!-- JQUERY SCRIPTS -->
        <script src="assets/js/jquery-1.10.2.js"></script>
        <!-- BOOTSTRAP SCRIPTS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- METISMENU SCRIPTS -->
        <script src="assets/js/jquery.metisMenu.js"></script>
        <!-- DATA TABLE SCRIPTS -->
        <script src="assets/js/dataTables/jquery.dataTables.js"></script>
        <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <!-- ALERT SCRIPTS -->
        <script src="assets/js/bootbox.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });


            function delConf(id){
                bootbox.confirm({
                    message: "Are you sure you want to delete it?",
                    buttons: {
                        confirm: {
                            label: 'Yes',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result == true){
                            window.location.href= '<?= basename($_SERVER['SCRIPT_NAME']) ?>?delete='+ id;
                        }
                    }
                });
            }
            function stop(id){
                var x = document.getElementById("mycheck"+id).checked;
                if(x == true){
                    $.get( "<?= basename($_SERVER['SCRIPT_NAME']) ?>?s=0&id="+id, function( data ) {
                        console.log( "Data Loaded:0 " );
                    });
                }else{
                    $.get( "<?= basename($_SERVER['SCRIPT_NAME']) ?>?s=1&id="+id, function( data ) {
                        console.log( "Data Loaded1: " );
                    });

                }


            }
        </script>
        <!-- CUSTOM SCRIPTS -->
        <script src="assets/js/custom.js"></script>


        </body>
    </html>
