<?php 
 session_start(); 
  if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";

$extensions_autorisees = array('.jpg','.JPG','.png','.PNG');

if (!empty($_POST)) {
$file_name=$_FILES['file']['name'];
  $file_extension=strrchr($file_name,".");
  $file_tmp_name=$_FILES['file']['tmp_name'];
  $file_dest='files/images/'.$file_name;
  $file_dest1='../files/images/'.$file_name;
$id=$_GET['id'];
  if(in_array($file_extension,$extensions_autorisees) || empty($file_extension )){
$req = $db->prepare('INSERT INTO news_picture (news_id,link) VALUES(?,?)');
$req->execute(array($id,$file_dest));
move_uploaded_file($file_tmp_name,$file_dest1);
?>

<?php 
}else {
$erreur2='Extension allowed .jpg,.JPG,.png,.PNG ';
}
 
  $s = '<div class="alert alert-success alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

    <strong>Success!</strong> Done Added
</div>

<meta http-equiv="refresh" content="3;url=news.php">';
}
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>New Picture</h2>   
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                     
                        <div class="panel-body">
                                                                     <?php
                        echo @$s;
                    ?>
                            <div class="table-responsive">
        
                          <form method="post" action="" enctype="multipart/form-data">
                            
                            <?php 
            if(isset($erreur2)){

                      echo $erreur2;
                    } 
          
                     ?>
                              
                              <label style="color: #2c3e50">Upload Picture:  </label><br/>
                             <input type="file" name="file" id="file" placeholder="download the file"> <br/>
                             
                                <input style="width:100px;" type="submit" name="submit" value="Save">
                          </form>
                                
                    
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
