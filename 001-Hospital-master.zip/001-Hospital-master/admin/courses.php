<?php 
 session_start(); 
  if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
 if (isset($_GET['delete'])) 
 {
                    $id=$_GET['delete'];
                    $reponse=$db->query("DELETE FROM training_courses WHERE id='$id'");
                    ?>

<?php 

 }
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Courses</h2>   
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                   <div class="panel panel-default">
                       
                        <div class="panel-body">
                                                   <?php
    if (isset($_GET['delete']))
    {
        echo '<div class="alert alert-success alert-dismissable">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

  <strong>Success!</strong> Done Deleted
</div>';

echo "<meta http-equiv='refresh' content='3;url=".basename($_SERVER['SCRIPT_NAME'])."'>";

              }
                        ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>date From</th>
                                            <th>Time From</th>
                                            <th>date From</th>
                                            <th>Time To</th>
                                            <th>Presented By</th>
                                            <th>Place</th>
                                            <th>Language</th>
                                            <th>File</th>
                                            <th> Delete </th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php 
$test1 = $db->query("SELECT*FROM training_courses");
$test1->execute();
 while($resultat1 = $test1->fetch()){

?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $resultat1['title'] ; ?></td>
                                            <td><?php echo $resultat1['date_from'] ; ?></td>
                                            <td><?php echo $resultat1['time_from'] ; ?></td>
                                            <td><?php echo $resultat1['date_to'] ; ?></td>
                                            <td><?php echo $resultat1['time_to'] ; ?></td>
                                            <td><?php echo $resultat1['presented_by'] ; ?></td>
                                            <td><?php echo $resultat1['place'] ; ?></td>
                                            <td><?php echo $resultat1['language'] ; ?></td>
                          
                                            <td><a href="../<?php echo $resultat1['link']; ?>" download >
                                    <span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span>  </a>  </td>
                                             <td class="center">
                                            <a href="#" class="btn btn-info" onclick="delConf('<?php echo $resultat1['id']; ?>')">
                                                <i class="fa fa-trash-o" aria-hidden="true"></i>
                                            </a>
                                        </td>  
                                     
                                        </tr>
<?php 
}
?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        <a href="newcourse.php"><h4><i class="fa fa-plus" aria-hidden="true"></i> Add Course </h4> </a> 
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
         <!-- ALERT SCRIPTS -->
        <script src="assets/js/bootbox.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });


            function delConf(id){
                bootbox.confirm({
                    message: "Are you sure you want to delete it?",
                    buttons: {
                        confirm: {
                            label: 'Yes',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-danger'
                        }
                    },
                    callback: function (result) {
                        if(result == true){
                            window.location.href= '<?= basename($_SERVER['SCRIPT_NAME']) ?>?delete='+ id;
                        }
                    }
                });
            }
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
