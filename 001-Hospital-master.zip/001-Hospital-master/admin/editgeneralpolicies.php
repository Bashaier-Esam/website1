<?php 
 session_start(); 
  if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
 $title= (isset($_POST['title'])) ? htmlspecialchars($_POST['title']) :'';
if (!empty($_POST)) {

$id=$_GET['edit'];
$req=$db->query("UPDATE general_policies_chapters SET title='$title' WHERE id= '$id'");
header('Location:generalpolicies.php');

}
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>General Policies</h2>   
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                   <div class="panel panel-default">
                        <div class="panel-heading">
                             General Policies
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <?php 
  
                $id=$_GET['edit'];

$test2 = $db->query("SELECT*FROM general_policies_chapters WHERE id=$id");
$test2->execute();
$resultat2 = $test2->fetch();

?>
          
                <form action="" method="post">
                  <input type="text" name="title" id="title" value="<?php echo $resultat2['title'] ; ?>">
                  <input type="submit" name="submit" value="Edit">
                </form>
                                </table>
                            </div>
                            </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
