<?php
try
{

                         $db = new PDO('mysql:host=localhost;dbname=hospital','admin','adminbashaier');
                         $db->setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);
                         $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                         }
                          catch(Exception $e){

                             echo 'une erreur est survenue';
                           die();
                            }



?>