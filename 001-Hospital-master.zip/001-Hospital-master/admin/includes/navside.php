<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/download.jpg" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a class="active-menu"  href="index.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>	                 
                    <li>
                        <a href="#"> <i class="fa fa-home fa-3x" aria-hidden="true"></i> IndexPage<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href="carousel.php"><i class="fa fa-list-alt" aria-hidden="true"></i>Index Carousel</a>
                            </li>
                            <li>
                                <a href="index_video.php"><i class="fa fa-video-camera" aria-hidden="true"></i>Index Videos</a>
                            </li>
                        </ul>
                      </li>  
                   <li>
                        <a href="#"> <i class="fa fa-list fa-3x" aria-hidden="true"></i> Departments & Centers<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href=""><i class="fa fa-list-alt" aria-hidden="true"></i> Departments <span class="fa arrow"></span></a>
                             <ul class="nav nav-second-level">
                             <li>
                                <a href="departments.php"><i class="fa fa-list-alt" aria-hidden="true"></i>All Departmens</a>
                            </li>
                            <li>
                                <a href="newdepartment.php"><i class="fa fa-plus" aria-hidden="true"></i>  Add New Department</a>
                            </li>
                            <li>
                                <a href="newmedicalstaf.php"><i class="fa fa-plus" aria-hidden="true"></i>  Add New Medical staff</a>
                            </li>
                        </ul>
                            </li>
                            <li>
                                <a href="allproducts.php"><i class="fa fa-list-alt" aria-hidden="true"></i> Centers <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href="centers.php"><i class="fa fa-list-alt" aria-hidden="true"></i>All Centers</a>
                            </li>
                            <li>
                                <a href="newcenter.php"><i class="fa fa-plus" aria-hidden="true"></i>  Add New Centers</a>
                            </li>
                            <li>
                                <a href="newmedicalstafcenter.php"><i class="fa fa-plus" aria-hidden="true"></i>  Add New Medical staff</a>
                            </li>
                        </ul>
                            </li>
                        </ul>
             </li>  

               <li>
                        <a href="#"> <i class="fa fa-list fa-3x" aria-hidden="true"></i> Quality & Safety<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href=""><i class="fa fa-list-alt" aria-hidden="true"></i>Policies & procedures <span class="fa arrow"></span></a>
                             <ul class="nav nav-second-level">
                             <li>
                                <a href="generalpolicies.php"><i class="fa fa-list-alt" aria-hidden="true"></i>General Policies</a>
                            </li>
                            <li>
                                <a href="departmentalpolicies.php"><i class="fa fa-list-alt" aria-hidden="true"></i>  Departmental Policies</a>
                            </li>
                        </ul>
                            </li>
                            <li>
                                <a href=""><i class="fa fa-list-alt" aria-hidden="true"></i> Clinical Procedures & Guidelines <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                             <li>
                                <a href="clinical.php"><i class="fa fa-list-alt" aria-hidden="true"></i>Policies</a>
                            </li>
                        </ul>
                            </li>
                        <li>
                        <a   href="tqmbook.php"><i class="fa fa-book" aria-hidden="true"></i> Books</a>
                        </li>
                        <li>
                        <a   href="tqmpresentation.php"><i class="fa fa-list-alt" aria-hidden="true"></i> Orientations</a>
                        </li>
                        <li>
                        <a   href="videos.php"><i class="fa fa-video-camera" aria-hidden="true"></i> Videos</a>
                    </li>
                        </ul>
             </li>  
               <li>
                        <a href="#"> <i class="fa fa-list fa-3x" aria-hidden="true"></i> Media<span class="fa arrow"></span></a>
                          <ul class="nav nav-second-level">
                             <li>
                                <a href="news.php"><i class="fa fa-newspaper-o" aria-hidden="true"></i>News</a>
                            </li>
                            <li>
                                <a href="events.php"><i class="fa fa-calendar" aria-hidden="true"></i>Events</a>
                            </li>
                        </ul>
                        </li>  

                  <li>
                        <a href="#"> <i class="fa fa-list fa-3x" aria-hidden="true"></i> Training<span class="fa arrow"></span></a>
                          <ul class="nav nav-second-level">
                             <li>
                        <a   href="courses.php"><i class="fa fa-book" aria-hidden="true"></i> Courses</a>
                        </li>
                        <li>
                        <a   href="hrbook.php"><i class="fa fa-book" aria-hidden="true"></i> Books</a>
                        </li>
                        <li>
                        <a   href="hrvideo.php"><i class="fa fa-video-camera" aria-hidden="true"></i> Videos</a>
                    </li>
                    <li>
                        <a   href="hrpresentation.php"><i class="fa fa-caret-square-o-left" aria-hidden="true"></i> Presentations</a>
                    </li>
                            <li>
                                <a href="courseplan.php"><i class="fa fa-calendar" aria-hidden="true"></i>Course Plan</a>
                            </li>
                        </ul>
                        </li>   
                </ul>
               
            </div>
            
        </nav>  