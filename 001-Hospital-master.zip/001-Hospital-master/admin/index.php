<?php 
 session_start(); 
   if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
include"connect.php";

?>
<?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Admin Dashboard</h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-list-alt" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail = $db->prepare("SELECT*FROM centers");
$reqmail ->execute();
$mailexist=$reqmail->rowCount();
?>
                    <p class="main-text"><?php echo $mailexist  ; ?> </p>
                    <p class="text-muted">Centers</p>
                </div>
             </div>
		     </div>
                    <div class="col-md-3 col-sm-6 col-xs-6">           
			<div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-list-alt" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail1 = $db->prepare("SELECT*FROM departments");
$reqmail1 ->execute();
$mailexist1=$reqmail1->rowCount();
?>
                    <p class="main-text"><?php echo $mailexist1  ;  ?> </p>
                    <p class="text-muted">Departments</p>
                </div>
             </div>
		     </div>
<div class="col-md-3 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-user" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail4 = $db->prepare("SELECT*FROM medical_staf");
$reqmail4 ->execute();
$mailexist4=$reqmail4->rowCount();
$reqmail5 = $db->prepare("SELECT*FROM medical_staf_center");
$reqmail5 ->execute();
$mailexist5=$reqmail5->rowCount();
$som1=$mailexist4 + $mailexist5;
?>
                    <p class="main-text"><?php echo $som1  ;  ?> </p>
                    <p class="text-muted">Medical Staf</p>
                </div>
             </div>
             </div>        
   <div class="col-md-3 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-book" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail2 = $db->prepare("SELECT*FROM training_books");
$reqmail2 ->execute();
$mailexist2=$reqmail2->rowCount();
$reqmail3 = $db->prepare("SELECT*FROM quality_safety_books");
$reqmail3 ->execute();
$mailexist3=$reqmail3->rowCount();
$som=$mailexist2 + $mailexist3;
?>
                    <p class="main-text"><?php echo $som  ;  ?> </p>
                    <p class="text-muted">Books</p>
                </div>
             </div>
             </div>   

<div class="col-md-3 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-video-camera" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail6 = $db->prepare("SELECT*FROM videos");
$reqmail6 ->execute();
$mailexist6=$reqmail6->rowCount();
$reqmail7 = $db->prepare("SELECT*FROM training_videos");
$reqmail7 ->execute();
$mailexist7=$reqmail7->rowCount();
$som2=$mailexist7 + $mailexist6;
?>
                    <p class="main-text"><?php echo $som2 ;  ?> </p>
                    <p class="text-muted">Videos</p>
                </div>
             </div>
             </div>        
<div class="col-md-3 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-file-text-o" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail8 = $db->prepare("SELECT*FROM news");
$reqmail8 ->execute();
$mailexist8=$reqmail8->rowCount();

?>
                    <p class="main-text"><?php echo $mailexist8 ;  ?> </p>
                    <p class="text-muted">News</p>
                </div>
             </div>
             </div>        

<div class="col-md-3 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                 <i class="fa fa-file-text-o" aria-hidden="true"></i>
                </span>
                <div class="text-box" >
<?php
$reqmail9= $db->prepare("SELECT*FROM events");
$reqmail9 ->execute();
$mailexist9=$reqmail9->rowCount();

?>
                    <p class="main-text"><?php echo $mailexist9 ;  ?> </p>
                    <p class="text-muted">Events</p>
                </div>
             </div>
             </div>        
                 </div>
                 <!-- /. ROW  -->
                <hr />                
                
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
