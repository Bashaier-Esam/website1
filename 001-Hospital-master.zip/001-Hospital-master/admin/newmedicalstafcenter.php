<?php
 session_start();
  if (!isset($_SESSION['id']))
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
$name= (isset($_POST['name'])) ? htmlspecialchars($_POST['name']) :'';
$fonction=(isset($_POST['fonction'])) ? htmlspecialchars($_POST['fonction']):'';
$email=(isset($_POST['email'])) ? htmlspecialchars($_POST['email']):'';
$education= (isset($_POST['education'])) ? htmlspecialchars($_POST['education']) :'';
$experience=(isset($_POST['experience'])) ? htmlspecialchars($_POST['experience']):'';
$center= (isset($_POST['center'])) ? htmlspecialchars($_POST['center']) :'';
$ext=(isset($_POST['ext'])) ? htmlspecialchars($_POST['ext']):'';
$extensions_autorisees = array('.png','.PNG','.jpg','.JPG');

if (!empty($_POST)) {
$file_name=$_FILES['img']['name'];
  $file_extension=strrchr($file_name,".");
  $file_tmp_name=$_FILES['img']['tmp_name'];
  $file_dest='files/images/'.$file_name;
  $file_dest1='../files/images/'.$file_name;

   $file_nameF=$_FILES['file']['name'];
    $file_extensionF=strrchr($file_nameF,".");
    $file_tmp_nameF=$_FILES['file']['tmp_name'];
    $file_destF='files/doc/'.$file_nameF;
    $file_dest1F='../files/doc/'.$file_nameF;



$test1 = $db->query("SELECT*FROM centers WHERE id=$center");
$test1->execute();
$resultat1 = $test1->fetch();
$center_name=$resultat1['name'];
  if(in_array($file_extension,$extensions_autorisees) || empty($file_extension )){

$req = $db->prepare('INSERT INTO medical_staf_center (name,fonction,email,education,experience,ext,center_name,center_id,img,file) VALUES(?,?,?,?,?,?,?,?,?,?)');
$req->execute(array($name,$fonction,$email,$education,$experience,$ext,$center_name,$center,$file_dest,$file_destF));
move_uploaded_file($file_tmp_name,$file_dest1);
move_uploaded_file($file_tmp_nameF,$file_dest1F);
?>

<?php

}else {
$erreur2='Extension allowed .png,.PNG,jpg,JPG ';
}
   $s = '<div class="alert alert-success alert-dismissable">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

    <strong>Success!</strong> Done Added
</div>

<meta http-equiv="refresh" content="3;url=centers.php">';

}
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>New Medical Staff</h2>

                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">

                        <div class="panel-body">

                             <?php
                        echo @$s;
                    ?>
                            <div class="table-responsive">

                          <form method="post" action="" enctype="multipart/form-data">
   <div class="form-group">
                            <label style="color:#2c3e50"> Name:</label><br/>
                            <input class="form-control" style="width:100%;" type="text" name="name" id="name" required>
                            <?php
            if(isset($erreur2)){

                      echo $erreur2;
                    }

                     ?>
                              </div>

                                 <div class="form-group">
                              <label style="color:#2c3e50">Select Picture:</label><br/>
                             <input type="file" name="img" id="img" placeholder="download the picture" required>
                              </div>

                                 <div class="form-group">
                             <label style="color:#2c3e50"> Specialty:</label> <br/>
                             <input class="form-control" style="width:100%;" type="text" name="fonction" id="fonction" required>
                              </div>

   <div class="form-group">
                              <label style="color:#2c3e50"> Email:</label><br/>
                              <input class="form-control" style="width:100%;" type="email" name="email" id="email" required>
                              </div>
   <div class="form-group">
                               <label style="color:#2c3e50"> Education:</label><br/>
                              <textarea class="form-control" style="width:100%;height:150px" name="education" id="education " required> </textarea>
                              </div>

                                  <div class="form-group">
                              <label style="color:#2c3e50"> Experience:</label><br/>
                                <textarea  class="form-control" style="width:100%;height:150px" name="experience" id=" experience"></textarea>
                              </div>

                                 <div class="form-group">
                                <label style="color:#2c3e50"> Ext:</label> <br/>
                             <input class="form-control" style="width:100%;" type="text" name="ext" id="ext" required>
                              </div>

   <div class="form-group">
                              <label style="color:#2c3e50"> Department Name:</label><br/>
                              <select class="form-control" style="width:100%;" id="center" name="center" required>
               <?php

 $test1 = $db->query("SELECT*FROM centers ");
$test1->execute();
 while($resultat1 = $test1->fetch()){
?>
                              <option value="<?php echo $resultat1['id']; ?>"> <?php echo $resultat1['name']; ?>   </option>

<?php
}
?>

                              </select>


            <div class="form-group">
                                    <label style="color: #2c3e50">File:  </label><br/>
                                    <input class="form-control" type="file" name="file" id="file" >

                                </div>
                              </div>
                                <input style="width:250px;" type="submit" name="submit" value="Save">
                          </form>


                            </div>

                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
