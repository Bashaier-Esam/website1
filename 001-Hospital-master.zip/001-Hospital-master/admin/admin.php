<?php 


 include"connect.php";

 
// Hachage du mot de passe


if (!empty($_POST)) {
  $pass_hache = $_POST['password'];
$user =$_POST['user'];
// Vérification des identifiants
$req = $db->prepare('SELECT id FROM admin WHERE user = :user AND password = :password');
$req->execute(array('user' => $user ,'password' => $pass_hache));
$resultat = $req->fetch();
if (!$resultat)
{
  $erreur= 'Invalid user or password';
   
}
else
{
    session_start();
    $_SESSION['id'] = $resultat['id'];
    $_SESSION['user'] = $user;
    header("Location:index.php?id=".$_SESSION['id']);
    exit;
}
}
?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Hospital-master - Log-in</title>

  <link rel='stylesheet' href='http://codepen.io/assets/libs/fullpage/jquery-ui.css'>

    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />

</head>

<body>

  <div class="login-card">
    <h1>Log-in</h1><br>
  <form method="post" action="">
    <input type="text" name="user" id="user" placeholder="Username">
    <input type="password" id="password" name="password" placeholder="Password">
    <input type="submit" name="login" class="login login-submit" value="login">
  </form>
<?php 
                    if(isset($erreur)){

                      echo $erreur;
                    } 
                    ?>
  <div class="login-help">
  </div>
</div>

<!-- <div id="error"><img src="https://dl.dropboxusercontent.com/u/23299152/Delete-icon.png" /> Your caps-lock is on.</div> -->

  <script src='http://codepen.io/assets/libs/fullpage/jquery_and_jqueryui.js'></script>

</body>

</html>