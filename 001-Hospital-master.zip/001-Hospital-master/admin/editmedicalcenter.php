<?php
 session_start();
  if (!isset($_SESSION['id']))
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
$name= (isset($_POST['name'])) ? htmlspecialchars($_POST['name']) :'';
$fonction=(isset($_POST['fonction'])) ? htmlspecialchars($_POST['fonction']):'';
$email=(isset($_POST['email'])) ? htmlspecialchars($_POST['email']):'';
$education= (isset($_POST['education'])) ? htmlspecialchars($_POST['education']) :'';
$experience=(isset($_POST['experience'])) ? htmlspecialchars($_POST['experience']):'';
if (!empty($_POST)) {
$id=$_GET['edit'];
$req=$db->query("UPDATE medical_staf_center SET name='$name',fonction= '$fonction',email= '$email', education='$education',experience= '$experience'  WHERE id= '$id'");

}
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Medical Staff</h2>

                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">

                        <div class="panel-body">
                            <div class="table-responsive">
  <?php
  $id=$_GET['edit'];
$test1 = $db->query("SELECT*FROM medical_staf_center WHERE id=$id");
$test1->execute();
$resultat1 = $test1->fetch();

?>

                          <form method="post" action="">

                            <div class="form-group">
                            <label style="color: #2c3e50"> Name:</label><br/>
                            <input class="form-control" style="width:100%" type="text" name="name" id="name" value="<?php echo $resultat1['name'] ; ?> ">
                              </div>

                                 <div class="form-group">
                             <label style="color: #2c3e50"> Department Name</label> <br/>
                             <input class="form-control" style="width:100%;" type="text" name="fonction" id="fonction" value=" <?php echo $resultat1['fonction'] ; ?> ">
                              </div>

                                 <div class="form-group">
                              <label style="color: #2c3e50"> Email:</label><br/>
                              <input  class="form-control"style="width:100%" type="email" name="email" id="email" value="<?php echo $resultat1['email'] ; ?> ">
                              </div>

   <div class="form-group">
                               <label style="color: #2c3e50"> Education:</label><br/>
                              <textarea  class="form-control"style="width:100%;height:150px" name="education" id="education "> <?php echo $resultat1['education'] ; ?></textarea>
                              </div>

                                 <div class="form-group">
                               <label style="color: #2c3e50"> Experience:</label><br/>
                                <textarea class="form-control" style="width:100%;height:150px" name="experience" id=" experience">  <?php echo $resultat1['experience'] ; ?></textarea>
                              </div>


                                <input type="submit" name="submit" value="EDIT">
                          </form>


                            </div>

                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
