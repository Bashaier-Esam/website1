<?php
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM `departments` WHERE name=?");
$stmt->execute(array($name));
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  $name_count = $row["count"];
}
if ($name_count < 0) {
  //insert
}
?>