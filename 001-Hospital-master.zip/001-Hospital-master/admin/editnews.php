<?php 
 session_start(); 
  if (!isset($_SESSION['id'])) 
   {
  header('Location:admin.php');
     exit;

  }
 include"connect.php";
$title= (isset($_POST['title'])) ? htmlspecialchars($_POST['title']) :'';
$text= (isset($_POST['text'])) ? htmlspecialchars($_POST['text']) :'';


if (!empty($_POST)) {
$sd=$_GET['edit'];

$req=$db->prepare("UPDATE news SET title='$title', text='$text' WHERE id= ? ");
$req->execute(array($sd));
?>
<script type="text/javascript">
alert("Success");
window.location.href="news.php";
</script>
<?php 
}
 ?>
 <?php
include"includes/header.php"
?>
           <!-- /. NAV TOP  -->
           <?php 

                include"includes/navside.php"

                ?>

<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>News</h2>   
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
           <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            News
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
  <?php 
  $id=$_GET['edit'];
$test1 = $db->query("SELECT*FROM news WHERE id=$id");
$test1->execute();
 $resultat1 = $test1->fetch();

?>      
                          <form method="post" action="" enctype="multipart/form-data">
                            <label style="color:blue"> News Title</label><br/>
                            <input style="width:400px;" type="text" name="title" id="title" value="<?php echo $resultat1['title']; ?>" required><br/>
                             <label style="color:blue"> Text  </label><br/>
                             <textarea style="width:400px;height:100px;" id="text" name="text"> <?php echo $resultat1['text']; ?></textarea> <br/> <br/>
                                <input style="width:400px;" type="submit" name="submit" value="Save">
                          </form>
                                
                    
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>

         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
