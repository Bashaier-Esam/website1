-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2017 at 07:01 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user`, `password`) VALUES
(1, 'Admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `centers`
--

CREATE TABLE `centers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `centers`
--

INSERT INTO `centers` (`id`, `name`, `img`) VALUES
(1, 'center1', 'files/images/news_001.jpg'),
(2, 'center 1', 'files/images/0cardio.v1.png'),
(3, 'lol', 'files/images/0cardio.v1.png'),
(4, 'center 2', 'files/images/002.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `clinical_procedures_guidelines_chapters`
--

CREATE TABLE `clinical_procedures_guidelines_chapters` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clinical_procedures_guidelines_chapters`
--

INSERT INTO `clinical_procedures_guidelines_chapters` (`id`, `title`, `data`) VALUES
(1, 'Chpater 1', '2017-12-28 12:04:42');

-- --------------------------------------------------------

--
-- Table structure for table `clinical_procedures_guidelines_policy`
--

CREATE TABLE `clinical_procedures_guidelines_policy` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clinical_procedures_guidelines_policy`
--

INSERT INTO `clinical_procedures_guidelines_policy` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'center 1', 'files/doc/recapitulatif-pre-inscription-i3s.pdf', 'files/doc/Cv.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `departmental_policies`
--

CREATE TABLE `departmental_policies` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departmental_policies`
--

INSERT INTO `departmental_policies` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'police 1', 'files/doc/AppPdf1.pdf', 'files/doc/test.pdf'),
(2, '1', 'department 1', 'files/doc/rapport-de-projet-culturel.pdf', 'files/doc/recapitulatif-pre-inscription-i3s.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `departmental_policies_chapter`
--

CREATE TABLE `departmental_policies_chapter` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departmental_policies_chapter`
--

INSERT INTO `departmental_policies_chapter` (`id`, `title`, `data`) VALUES
(1, 'chapter 1', '2017-12-28 11:42:06');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `ext` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `img`, `text`, `ext`) VALUES
(1, 'Dental Department', 'files/images/news_001.jpg', '', 0),
(3, 'bashaier', 'files/images/0derma.v1.jpg', '', 0),
(4, 'test', 'files/images/0cardio.v1.png', '', 0),
(5, 'test', 'files/images/0derma.v1.jpg', '', 0),
(6, 'lol', 'files/images/0cardio.v1.png', '', 0),
(7, '555', 'files/images/0eent.jpg', '', 0),
(8, 'please ', 'files/images/adel. sh.jpg', 'hjsdbvj\r\nDental Department Services\r\nDental Department Services\r\nDental Department Services\r\nDental Department Services\r\n', 1234),
(9, 'et', 'files/images/abulmajarem.jpg', 'Dental Department Services &lt;br&gt;\r\nDental Department Services &lt;br&gt;\r\nDental Department Services\r\nDental Department Services\r\n', 1234),
(10, 'po', 'files/images/abulmajarem.jpg', 'fghj\r\ngfff\r\ngfff\r\ngfff', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `text`, `img`, `status`) VALUES
(3, 'hhhhh', 'hhh hhh hhh  hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh hhh ', 'files/images/0dental.v1.png', 0),
(4, 'yy', 'gf', 'files/images/0cardio.v1.png', 0),
(5, 'yy', 'hg', 'files/images/0cardio.v1.png', 0),
(6, 'yy', 'fghjm', 'files/images/0cardio.v1.png', 0),
(7, 'yy', 'ttt', 'files/images/0cardio.v1.png', 0),
(8, 'title', 'text text', 'files/images/0cardio.v1.png', 1),
(9, 'abdo ', ';', 'files/images/spevents2.jpg', 0),
(10, 'oiuiujd', 'xcfgh', 'files/images/event3.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `events_id`
--

CREATE TABLE `events_id` (
  `id` int(11) NOT NULL,
  `events_id` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events_id`
--

INSERT INTO `events_id` (`id`, `events_id`, `link`) VALUES
(9, '10', 'files/images/events3-3.png'),
(8, '9', 'files/images/spevents021.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `general_policies`
--

CREATE TABLE `general_policies` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `general_policies`
--

INSERT INTO `general_policies` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'Policy 1', 'files/doc/Cv.pdf', 'files/doc/Sara rapp.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `general_policies_chapters`
--

CREATE TABLE `general_policies_chapters` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `general_policies_chapters`
--

INSERT INTO `general_policies_chapters` (`id`, `title`, `data`) VALUES
(1, 'chapter 1', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `index_carousel`
--

CREATE TABLE `index_carousel` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `index_carousel`
--

INSERT INTO `index_carousel` (`id`, `link`) VALUES
(9, 'files/images/555.jpg'),
(10, 'files/images/Untitled.png');

-- --------------------------------------------------------

--
-- Table structure for table `index_news`
--

CREATE TABLE `index_news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `index_news`
--

INSERT INTO `index_news` (`id`, `title`, `text`, `img`) VALUES
(1, 'Card title', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(2, 'Card title1', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(3, 'Card title2', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(4, 'Card title3', 'Some quick example text to build on the card title and make up the bulk e up the bulk of the card\'s contente up the bulk of the card\'s contente up the bulk of the card\'s contentof the card\'s content.', 'files/images/news_004.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `index_video`
--

CREATE TABLE `index_video` (
  `id` int(11) NOT NULL,
  `vid` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `index_video`
--

INSERT INTO `index_video` (`id`, `vid`) VALUES
(1, 'files/vid/Saudi German Hospitals.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `medical_staf`
--

CREATE TABLE `medical_staf` (
  `id` int(11) NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `departement_name` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `file` text NOT NULL,
  `education` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medical_staf`
--

INSERT INTO `medical_staf` (`id`, `fonction`, `name`, `departement_name`, `department_id`, `email`, `ext`, `img`, `file`, `education`, `experience`) VALUES
(1, ' Head of Department      ', 'Dr. Ahmed Ibrahim  ', 'Dental Department', '1', 'dn1.med@sghgroup.net', '765', 'files/images/doc001.jpg', '', 'Doctor of Medicine : Seoul National University\nBachelor of Medicine : Seoul National Universit', 'Assistant Professor in UUCM AMC\r\nResearch Fellowship in Allergy, UUCM AMC\r\nPost Doctor, NIH\r\nPost Doctor, POSTECH'),
(5, 'dentAL', '123', '555', '7', 'lo@hotmail.com', '1231', 'files/images/0cardio.v1.png', 'files/doc/IPC_012.5Pregnant_Healthcare_Workers.PDF', ' lolleoeleoeloel', 'loleoleoeloeeloeloe'),
(6, 'in', 'bashaier', 'test', '4', 's@hotmail', '12345', 'files/images/0eent.jpg', 'files/doc/Cardiology - Mohammed Omar Al Shahat.pdf', ' jhgfds', 'kjhg'),
(7, 'jhgf', 'adel bai', 'Dental Department', '1', 'a@fghjk', '12345', 'files/images/0cardio.v1.png', 'files/doc/IPC003.0 Annex-Annex-I.PDF', ' dfghj', '');

-- --------------------------------------------------------

--
-- Table structure for table `medical_staf_center`
--

CREATE TABLE `medical_staf_center` (
  `id` int(11) NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `center_id` varchar(255) NOT NULL,
  `center_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `file` text NOT NULL,
  `education` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medical_staf_center`
--

INSERT INTO `medical_staf_center` (`id`, `fonction`, `name`, `center_id`, `center_name`, `email`, `ext`, `img`, `file`, `education`, `experience`) VALUES
(1, '  Head of Department  ', 'Dr. Ahmed Ibrahim', '1', 'Dental center', 'dn1.med@sghgroup.net', '765', 'files/images/doc001.jpg', '', '  Doctor of Medicine : Seoul National University\r\n\r\nBachelor of Medicine : Seoul National Universit', '    Assistant Professor in UUCM AMC\r\nResearch Fellowship in Allergy, UUCM AMC\r\nPost Doctor, NIH\r\nPost Doctor, POSTECH'),
(3, 'aefkhrr', 'tt', '4', 'center 2', 'd@fghj', '134', 'files/images/doc001.jpg', 'files/doc/Mon CV.pdf', ' gfhgjhkjk', 'fghjk');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `text`, `img`, `data`) VALUES
(5, 'SGH-MADINAH PARTICIPATION IN UROLOGY CLUB MEETING', 'Urologists at Saudi German Hospital- Madinah participated in the scientific conference which was organized under the auspices of Urology Club. Urologists at Al-Madinah Al-Mounawarah hospitals were invited to participate in the monthly urological conference. This conference reviewed the new advances in urological technology.The conference was managed by President of Urology Club in Al Madinah Dr. Emad Salama. He highly praised the outstanding urological services provided by all hospitals in Al-Madinah .He also thanked Saudi German hospital, represented by urological department , for sponsoring the conference. Consultant Urologist and Head of Urology Department Dr.Adel Farhat discussed a series of clinical complicated cases which have been treated at the hospital. Advanced devices and skills were used to treat these cases .These cases were presented to exchange views and experiences and to discuss the latest technologies used in the hospital.', '', '2017-12-26 13:53:20'),
(6, 'INFECTION CONTROL DURING HAJJ SEASON', 'In cooperation with Al Madinah Regional Municipality SGH-Madinah organized health campaign to define infection control during Hajj season SGH-Madinah in cooperation with Al Madinah Regional Municipality organized an awareness campaign to define infection control during Hajj season, where the campaign was held at the headquarters of AlMadinah Regional Municipality, the campaign included a free checkup for Al Madinah Regional Municipality staff and auditors, medical consultations on the infection and chronic diseases , explaining the symptoms and how to deal with these symptoms in case of observation on the infected.These initiatives are based on the provision of community services within the framework of the social responsibility programs in the hospital, which aims at continuous communication with various sectors in the region.', '', '2017-12-26 13:55:26'),
(7, 'SGH-MADINAH HELD A MEDICAL LECTURE COINCIDING WITH THE HAJJ FOR THE EMPLOYEES OF STC', 'As part of community service initiatives SGH-Madinah in cooperation with STC provided a free medical checkup, medical consultations and awareness lecture on infection control and dealing with symptoms and chronic diseases during Hajj for the staff of STC. These initiatives are based on the directives of Eng. Sobhi Batterjee to provide community services within the scope of social responsibility programs in the hospital, which aims to communicate continuously with various sectors in the region.', '', '2017-12-26 13:57:38'),
(8, 'bashaier', 'vc', '', '2017-12-27 12:41:19');

-- --------------------------------------------------------

--
-- Table structure for table `news_picture`
--

CREATE TABLE `news_picture` (
  `id` int(11) NOT NULL,
  `news_id` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news_picture`
--

INSERT INTO `news_picture` (`id`, `news_id`, `link`) VALUES
(1, '2', 'files/images/0dental.v1.png'),
(3, '3', 'files/images/0cardio.v1.png'),
(4, '4', 'files/images/0surg.v1.png'),
(5, '5', 'files/images/news1.jpg'),
(6, '6', 'files/images/news2.jpg'),
(7, '7', 'files/images/news3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `oriontations`
--

CREATE TABLE `oriontations` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `prepared_by` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oriontations`
--

INSERT INTO `oriontations` (`id`, `title`, `prepared_by`, `file`, `file_name`, `data`) VALUES
(1, 'Tiltle of presentation', 'Dr.Dalia', 'files/doc/test.pdf', 'Test', '2017-09-25 19:24:20');

-- --------------------------------------------------------

--
-- Table structure for table `quality_safety_books`
--

CREATE TABLE `quality_safety_books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quality_safety_books`
--

INSERT INTO `quality_safety_books` (`id`, `title`, `link`) VALUES
(1, 'Cebahi Book', 'files/doc/test.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `training_books`
--

CREATE TABLE `training_books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `training_books`
--

INSERT INTO `training_books` (`id`, `title`, `link`) VALUES
(1, 'Book1', 'files/doc/test.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `training_courses`
--

CREATE TABLE `training_courses` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_from` varchar(255) NOT NULL,
  `time_from` varchar(255) NOT NULL,
  `date_to` varchar(255) NOT NULL,
  `time_to` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `presented_by` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `training_courses`
--

INSERT INTO `training_courses` (`id`, `title`, `date_from`, `time_from`, `date_to`, `time_to`, `place`, `presented_by`, `language`, `link`, `data`) VALUES
(2, 'course1', '', '', '', '', '', '', '', '', '2017-09-26 23:08:42');

-- --------------------------------------------------------

--
-- Table structure for table `training_cousesplan`
--

CREATE TABLE `training_cousesplan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `training_cousesplan`
--

INSERT INTO `training_cousesplan` (`id`, `title`, `link`) VALUES
(1, 'course 1', 'files/doc/Sara rapp.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `training_presentation`
--

CREATE TABLE `training_presentation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `prepared_by` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `training_presentation`
--

INSERT INTO `training_presentation` (`id`, `title`, `prepared_by`, `link`, `data`) VALUES
(1, 'Presentation 1', 'Dr.Dalila', 'files/doc/test.pdf', '2017-09-26 23:34:29');

-- --------------------------------------------------------

--
-- Table structure for table `training_videos`
--

CREATE TABLE `training_videos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `training_videos`
--

INSERT INTO `training_videos` (`id`, `title`, `link`, `data`) VALUES
(2, 'vedio 1', 'files/vid/21173244_175975562947800_2790403586075394048_n.mp4', '2017-12-28 15:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `link`, `data`) VALUES
(1, 'Video1 ', 'files/vid/test1.mp4', '2017-09-24 23:21:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinical_procedures_guidelines_chapters`
--
ALTER TABLE `clinical_procedures_guidelines_chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinical_procedures_guidelines_policy`
--
ALTER TABLE `clinical_procedures_guidelines_policy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmental_policies`
--
ALTER TABLE `departmental_policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmental_policies_chapter`
--
ALTER TABLE `departmental_policies_chapter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_id`
--
ALTER TABLE `events_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_policies`
--
ALTER TABLE `general_policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_policies_chapters`
--
ALTER TABLE `general_policies_chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `index_carousel`
--
ALTER TABLE `index_carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `index_news`
--
ALTER TABLE `index_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `index_video`
--
ALTER TABLE `index_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical_staf`
--
ALTER TABLE `medical_staf`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical_staf_center`
--
ALTER TABLE `medical_staf_center`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_picture`
--
ALTER TABLE `news_picture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oriontations`
--
ALTER TABLE `oriontations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quality_safety_books`
--
ALTER TABLE `quality_safety_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_books`
--
ALTER TABLE `training_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_courses`
--
ALTER TABLE `training_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_cousesplan`
--
ALTER TABLE `training_cousesplan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_presentation`
--
ALTER TABLE `training_presentation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_videos`
--
ALTER TABLE `training_videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `clinical_procedures_guidelines_chapters`
--
ALTER TABLE `clinical_procedures_guidelines_chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `clinical_procedures_guidelines_policy`
--
ALTER TABLE `clinical_procedures_guidelines_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `departmental_policies`
--
ALTER TABLE `departmental_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `departmental_policies_chapter`
--
ALTER TABLE `departmental_policies_chapter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `events_id`
--
ALTER TABLE `events_id`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `general_policies`
--
ALTER TABLE `general_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `general_policies_chapters`
--
ALTER TABLE `general_policies_chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `index_carousel`
--
ALTER TABLE `index_carousel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `index_news`
--
ALTER TABLE `index_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `index_video`
--
ALTER TABLE `index_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `medical_staf`
--
ALTER TABLE `medical_staf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `medical_staf_center`
--
ALTER TABLE `medical_staf_center`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `news_picture`
--
ALTER TABLE `news_picture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `oriontations`
--
ALTER TABLE `oriontations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `quality_safety_books`
--
ALTER TABLE `quality_safety_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `training_books`
--
ALTER TABLE `training_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `training_courses`
--
ALTER TABLE `training_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `training_cousesplan`
--
ALTER TABLE `training_cousesplan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `training_presentation`
--
ALTER TABLE `training_presentation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `training_videos`
--
ALTER TABLE `training_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
