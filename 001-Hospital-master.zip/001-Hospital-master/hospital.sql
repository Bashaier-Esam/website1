-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Sam 30 Septembre 2017 à 14:40
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hospital`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`id`, `user`, `password`) VALUES
(1, 'Admin', 'admin');

-- --------------------------------------------------------

--
-- Structure de la table `centers`
--

CREATE TABLE `centers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `centers`
--

INSERT INTO `centers` (`id`, `name`, `img`) VALUES
(1, 'center1', 'files/images/news_001.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `clinical_procedures_guidelines_chapters`
--

CREATE TABLE `clinical_procedures_guidelines_chapters` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `clinical_procedures_guidelines_chapters`
--

INSERT INTO `clinical_procedures_guidelines_chapters` (`id`, `title`, `data`) VALUES
(1, 'chapter1', '2017-09-25 22:57:01'),
(2, 'chapter2', '2017-09-25 22:57:14');

-- --------------------------------------------------------

--
-- Structure de la table `clinical_procedures_guidelines_policy`
--

CREATE TABLE `clinical_procedures_guidelines_policy` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `clinical_procedures_guidelines_policy`
--

INSERT INTO `clinical_procedures_guidelines_policy` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'Policy 1', 'files/doc/test.pdf', NULL),
(3, '1', 'policy2', 'files/doc/', NULL),
(4, '2', 'ssss', 'files/doc/Sara rapp.pdf', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `departmental_policies`
--

CREATE TABLE `departmental_policies` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `departmental_policies`
--

INSERT INTO `departmental_policies` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'Policy1', '', NULL),
(2, '1', 'Policy2', '', NULL),
(4, '3', 'test', 'files/doc/Cv.pdf', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `departmental_policies_chapter`
--

CREATE TABLE `departmental_policies_chapter` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `departmental_policies_chapter`
--

INSERT INTO `departmental_policies_chapter` (`id`, `title`, `data`) VALUES
(1, 'chapter1', '2017-09-25 23:35:07');

-- --------------------------------------------------------

--
-- Structure de la table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `departments`
--

INSERT INTO `departments` (`id`, `name`, `img`) VALUES
(1, 'Dental Department', 'files/images/news_001.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `events`
--

INSERT INTO `events` (`id`, `title`, `text`, `img`) VALUES
(1, 'SHAREHOLDERS INVITATION TO GENERAL ASSEMBLY', 'MiddlMiddle MiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcEast Healthcare Company Middle East Healthc Middle East Healthcare Company Middle East Healthce East Healthcare Company Middle East Healthcare CompanyMiddle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates', 'files/images/event.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `events_id`
--

CREATE TABLE `events_id` (
  `id` int(11) NOT NULL,
  `events_id` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `events_id`
--

INSERT INTO `events_id` (`id`, `events_id`, `link`) VALUES
(1, '1', 'files/images/Hassan-II-Mosque-in-Casablanca-Morocco.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `general_policies`
--

CREATE TABLE `general_policies` (
  `id` int(11) NOT NULL,
  `chapter_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `option_file` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `general_policies`
--

INSERT INTO `general_policies` (`id`, `chapter_id`, `title`, `file`, `option_file`) VALUES
(1, '1', 'policy1', NULL, ''),
(5, '4', 'policy', 'files/doc/Sara rapp.pdf', ''),
(8, '1', 'testtt', 'files/doc/Sara rapp.pdf', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `general_policies_chapters`
--

CREATE TABLE `general_policies_chapters` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `general_policies_chapters`
--

INSERT INTO `general_policies_chapters` (`id`, `title`, `data`) VALUES
(1, 'Chapter1', '2017-09-25 23:26:59');

-- --------------------------------------------------------

--
-- Structure de la table `index_carousel`
--

CREATE TABLE `index_carousel` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `index_carousel`
--

INSERT INTO `index_carousel` (`id`, `link`) VALUES
(1, 'files/images/carousel_001.png'),
(2, 'files/images/carousel_002.png'),
(4, 'files/images/carousel_003.png');

-- --------------------------------------------------------

--
-- Structure de la table `index_news`
--

CREATE TABLE `index_news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `index_news`
--

INSERT INTO `index_news` (`id`, `title`, `text`, `img`) VALUES
(1, 'Card title', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(2, 'Card title1', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(3, 'Card title2', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg'),
(4, 'Card title3', 'Some quick example text to build on the card title and make up the bulk e up the bulk of the card\'s contente up the bulk of the card\'s contente up the bulk of the card\'s contentof the card\'s content.', 'files/images/news_004.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `index_video`
--

CREATE TABLE `index_video` (
  `id` int(11) NOT NULL,
  `vid` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `index_video`
--

INSERT INTO `index_video` (`id`, `vid`) VALUES
(1, 'files/vid/VID-20160720-WA0008.mp4');

-- --------------------------------------------------------

--
-- Structure de la table `medical_staf`
--

CREATE TABLE `medical_staf` (
  `id` int(11) NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `departement_name` varchar(255) NOT NULL,
  `department_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `medical_staf`
--

INSERT INTO `medical_staf` (`id`, `fonction`, `name`, `departement_name`, `department_id`, `email`, `ext`, `img`, `education`, `experience`) VALUES
(1, ' Head of Department      ', 'Dr. Ahmed Ibrahim  ', 'Dental Department', '1', 'dn1.med@sghgroup.net', '765', 'files/images/doc001.jpg', 'Doctor of Medicine : Seoul National University\nBachelor of Medicine : Seoul National Universit', 'Assistant Professor in UUCM AMC\r\nResearch Fellowship in Allergy, UUCM AMC\r\nPost Doctor, NIH\r\nPost Doctor, POSTECH');

-- --------------------------------------------------------

--
-- Structure de la table `medical_staf_center`
--

CREATE TABLE `medical_staf_center` (
  `id` int(11) NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `center_id` varchar(255) NOT NULL,
  `center_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ext` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `medical_staf_center`
--

INSERT INTO `medical_staf_center` (`id`, `fonction`, `name`, `center_id`, `center_name`, `email`, `ext`, `img`, `education`, `experience`) VALUES
(1, '  Head of Department  ', 'Dr. Ahmed Ibrahim', '1', 'Dental center', 'dn1.med@sghgroup.net', '765', 'files/images/doc001.jpg', '  Doctor of Medicine : Seoul National University\r\n\r\nBachelor of Medicine : Seoul National Universit', '    Assistant Professor in UUCM AMC\r\nResearch Fellowship in Allergy, UUCM AMC\r\nPost Doctor, NIH\r\nPost Doctor, POSTECH');

-- --------------------------------------------------------

--
-- Structure de la table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `news`
--

INSERT INTO `news` (`id`, `title`, `text`, `img`, `data`) VALUES
(1, 'SHAREHOLDERS INVITATION TO GENERAL ASSEMBLY', 'MiddlMiddle MiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcMiddlMiddle East Healthcare Company Middle East HealthcEast Healthcare Company Middle East Healthc Middle East Healthcare Company Middle East Healthce East Healthcare Company Middle East Healthcare CompanyMiddle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates', 'files/images/new.png', '2017-09-24 23:35:26'),
(2, 'Card title', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg', '2017-09-27 11:52:48'),
(3, 'Card title1', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 'files/images/news_001.jpg', '2017-09-27 11:53:35'),
(4, 'Card title3', 'Some quick example text to build on the card title...', 'files/images/news_004.jpg', '2017-09-27 11:54:11');

-- --------------------------------------------------------

--
-- Structure de la table `news_picture`
--

CREATE TABLE `news_picture` (
  `id` int(11) NOT NULL,
  `news_id` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `news_picture`
--

INSERT INTO `news_picture` (`id`, `news_id`, `link`) VALUES
(1, '2', 'files/images/21.jpg'),
(2, '2', 'files/images/images.jpg'),
(3, '2', 'files/images/keyboard-621830_960_720.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `oriontations`
--

CREATE TABLE `oriontations` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `prepared_by` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `oriontations`
--

INSERT INTO `oriontations` (`id`, `title`, `prepared_by`, `file`, `file_name`, `data`) VALUES
(1, 'Tiltle of presentation', 'Dr.Dalia', 'files/doc/test.pdf', 'Test', '2017-09-25 19:24:20');

-- --------------------------------------------------------

--
-- Structure de la table `quality_safety_books`
--

CREATE TABLE `quality_safety_books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `quality_safety_books`
--

INSERT INTO `quality_safety_books` (`id`, `title`, `link`) VALUES
(1, 'Cebahi Book', 'files/doc/test.pdf');

-- --------------------------------------------------------

--
-- Structure de la table `training_books`
--

CREATE TABLE `training_books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `training_books`
--

INSERT INTO `training_books` (`id`, `title`, `link`) VALUES
(1, 'Book1', 'files/doc/test.pdf');

-- --------------------------------------------------------

--
-- Structure de la table `training_courses`
--

CREATE TABLE `training_courses` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_from` varchar(255) NOT NULL,
  `time_from` varchar(255) NOT NULL,
  `date_to` varchar(255) NOT NULL,
  `time_to` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `presented_by` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `training_courses`
--

INSERT INTO `training_courses` (`id`, `title`, `date_from`, `time_from`, `date_to`, `time_to`, `place`, `presented_by`, `language`, `link`, `data`) VALUES
(2, 'course1', '', '', '', '', '', '', '', '', '2017-09-26 23:08:42');

-- --------------------------------------------------------

--
-- Structure de la table `training_cousesplan`
--

CREATE TABLE `training_cousesplan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `training_cousesplan`
--

INSERT INTO `training_cousesplan` (`id`, `title`, `link`) VALUES
(1, 'Course plan', 'files/doc/test.pdf');

-- --------------------------------------------------------

--
-- Structure de la table `training_presentation`
--

CREATE TABLE `training_presentation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `prepared_by` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `training_presentation`
--

INSERT INTO `training_presentation` (`id`, `title`, `prepared_by`, `link`, `data`) VALUES
(1, 'Presentation 1', 'Dr.Dalila', 'files/doc/test.pdf', '2017-09-26 23:34:29');

-- --------------------------------------------------------

--
-- Structure de la table `training_videos`
--

CREATE TABLE `training_videos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `training_videos`
--

INSERT INTO `training_videos` (`id`, `title`, `link`, `data`) VALUES
(1, 'Video 1', 'files/vid/test1.mp4', '2017-09-26 23:30:10');

-- --------------------------------------------------------

--
-- Structure de la table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `videos`
--

INSERT INTO `videos` (`id`, `title`, `link`, `data`) VALUES
(1, 'Video1 ', 'files/vid/test1.mp4', '2017-09-24 23:21:10');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clinical_procedures_guidelines_chapters`
--
ALTER TABLE `clinical_procedures_guidelines_chapters`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clinical_procedures_guidelines_policy`
--
ALTER TABLE `clinical_procedures_guidelines_policy`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `departmental_policies`
--
ALTER TABLE `departmental_policies`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `departmental_policies_chapter`
--
ALTER TABLE `departmental_policies_chapter`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `events_id`
--
ALTER TABLE `events_id`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `general_policies`
--
ALTER TABLE `general_policies`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `general_policies_chapters`
--
ALTER TABLE `general_policies_chapters`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `index_carousel`
--
ALTER TABLE `index_carousel`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `index_news`
--
ALTER TABLE `index_news`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `index_video`
--
ALTER TABLE `index_video`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `medical_staf`
--
ALTER TABLE `medical_staf`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `medical_staf_center`
--
ALTER TABLE `medical_staf_center`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `news_picture`
--
ALTER TABLE `news_picture`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `oriontations`
--
ALTER TABLE `oriontations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `quality_safety_books`
--
ALTER TABLE `quality_safety_books`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `training_books`
--
ALTER TABLE `training_books`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `training_courses`
--
ALTER TABLE `training_courses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `training_cousesplan`
--
ALTER TABLE `training_cousesplan`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `training_presentation`
--
ALTER TABLE `training_presentation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `training_videos`
--
ALTER TABLE `training_videos`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `clinical_procedures_guidelines_chapters`
--
ALTER TABLE `clinical_procedures_guidelines_chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `clinical_procedures_guidelines_policy`
--
ALTER TABLE `clinical_procedures_guidelines_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `departmental_policies`
--
ALTER TABLE `departmental_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `departmental_policies_chapter`
--
ALTER TABLE `departmental_policies_chapter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `events_id`
--
ALTER TABLE `events_id`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `general_policies`
--
ALTER TABLE `general_policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `general_policies_chapters`
--
ALTER TABLE `general_policies_chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `index_carousel`
--
ALTER TABLE `index_carousel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `index_news`
--
ALTER TABLE `index_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `index_video`
--
ALTER TABLE `index_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `medical_staf`
--
ALTER TABLE `medical_staf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `medical_staf_center`
--
ALTER TABLE `medical_staf_center`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `news_picture`
--
ALTER TABLE `news_picture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `oriontations`
--
ALTER TABLE `oriontations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `quality_safety_books`
--
ALTER TABLE `quality_safety_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `training_books`
--
ALTER TABLE `training_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `training_courses`
--
ALTER TABLE `training_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `training_cousesplan`
--
ALTER TABLE `training_cousesplan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `training_presentation`
--
ALTER TABLE `training_presentation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `training_videos`
--
ALTER TABLE `training_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
