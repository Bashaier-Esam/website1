﻿<?php
include"connect.php";
include"includes/header.php";

    if(isset($_GET['CID'])){
        $cid = $_GET['CID'];
        $test2 = $db->query("SELECT * FROM `clinical_procedures_guidelines_policy` WHERE chapter_id='$cid' ORDER BY id DESC LIMIT 300 ");
        $test2->execute();
    }



?>


<div class="col-md-3" style="padding-top:25px;">
 <div class="list-group">
						<a href="tqm" class="list-group-item active ">Quality & Safety </a>
						<a href="cebahichapters" class="list-group-item list-group-item-action" >Policies & procedures</a>
						<a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Protocols & Guidelines</a>
						<a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
						<a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
						<a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
					</div>
</div>

<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-3" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
               <!-- <div class="btn-group" role="group">
                    <a href="clinicalprocedureguideline" class="btn btn-primary">Introduction</a>
                </div>-->
                <div class="btn-group" role="group">
                    <a href="clinicalchapters" class="btn btn-primary">Policies</a>
                </div>

            </div>
        </div>

        <br> <br> <br>
        <div class="col-md-<?php if(isset($_GET['CID'])){ echo '12'; }else{ echo '9'; } ?>">

<div class="btn-group-vertical btn-block">
    <?php if(!isset($_GET['CID'])){
        $test1 = $db->query("SELECT * FROM `clinical_procedures_guidelines_policy` ");
        $test1->execute();
        while($resultat2 = $test1->fetch()){
    ?>
        <a href="?CID=<?php echo $resultat2['id'] ?>" class="btn btn-default"><?php echo $resultat2['title'] ?></a>
        <br>
    <?php
        }
}else{

          while($resultat3 = $test2->fetch()){
?>

<div class="media">
        <a href="<?php echo $resultat3['link']; ?>">
  <div class="media-left">

      <img class="media-object" style="
    width: 110px;
" src="files/images/BOOK.jpg" alt="...">

  </div>
  <div class="media-body">
    <h4 class="media-heading"  style="padding-top: 25px;"><?php echo $resultat3['title']; ?></h4>
<!--    ...-->
  </div>
</a>
</div>



    <?php

           }
 } ?>
</div>
        </div>

</div>
</div>



<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>