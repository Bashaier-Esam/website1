<?php
$path_parts = pathinfo('/www/htdocs/inc/li.b');


var_dump( @$path_parts['extension']);
if(@pathinfo('/www/htdocs/inc/li.b')['extension'] == null){
    echo "yup";
}
