﻿<?php
include"connect.php";
include 'includes/header.php' ?>

 <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a class="list-group-item active ">Department & Centers </a>
                <a href="departments" class="list-group-item list-group-item-action">Mmedical Departments</a>
                <a href="centers" class="list-group-item list-group-item-action">Services Area</a>
            </div>
        </div>
				<div class="col-md-9" style="padding-top:25px;">
				     	<div class="row">
				    <div class="col-md-5" >
					<div class="btn-group btn-group-justified" role="group" aria-label="...">
                    <div class="btn-group" role="group">
                       <?php
                        $id=$_GET['id'];
                        ?>
                            <a href="spdepartments.php?id=<?php echo $id ; ?>" class='btn btn-primary'>Services</a>
                        </div>
                    <div class="btn-group" role="group">
                   <a href="medicalstaffdep?id=<?php echo $id ; ?>" class='btn btn-primary'>Medical Staff</a>
                   </div>

                    </div>
					</div>
 <?php
 $id=$_GET['id'];
 $test2 = $db->query("SELECT*FROM medical_staf WHERE department_id=$id ");
$test2->execute();
 while($resultat2 = $test2->fetch()){
 ?>

					<div class="col-md-12" style="padding-top:25px"></div>

					<div class="col-md-3">
					<img class="card-img-top" src="<?php echo $resultat2['img']; ?>" alt="doc" style="width:150px;height:170px;">
					</div>

					<div class="col-md-6">
					<h4> <?php echo $resultat2['fonction']; ?></h4>
					 <hr noshade>
					 <?php echo $resultat2['name']; ?><br>
					 <?php echo $resultat2['departement_name']; ?><br>
					 <?php echo $resultat2['email']; ?><br>
				 Ext:<?php echo $resultat2['ext']; ?>  	 <p class="text-right"><a href="drdep.php?id=<?php echo $resultat2['id']; ?>"> More Doctor Info</a></p>
				 <hr noshade>
					</div>


<?php

}
?>





			    </div>
</div>

	  <div class="col-md-12">
	 <br><br>
	  </div>

	<?php include 'includes/footer.php' ?>