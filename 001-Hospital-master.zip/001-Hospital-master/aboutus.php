﻿<?php include"includes/header.php" ?>



       <div class="col-md-3" style="padding-top:25px;">
					<div class="list-group">
						<a href="#" class="list-group-item active ">About us </a>
						<a href="aboutus" class="list-group-item list-group-item-action">Introduction</a>
						<a href="PresidentSpeech" class="list-group-item list-group-item-action">  President Letter</a>
                          <a href="ceoSpeech" class="list-group-item list-group-item-action">CEO Letter</a>
						<a href="missionVision" class="list-group-item list-group-item-action">Mission & Vision</a>
					</div>
				</div>
        <div class="col-md-9">

            <div class="row">


                <h3>Introduction </h3><br>
                <div class="col-md-12" style="padding-top:25px"></div>

                <div class="col-md-5">

                    <img class="card-img-left" src="files/images/001.jpg" alt="we care" style="width:200px;height:250px;">
                </div>


                <div class="col-md-7">
                    <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>

                </div>
                <div class="col-md-12">
                    <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>

                </div>

            </div>
        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>