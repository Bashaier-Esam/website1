﻿<?php
include"connect.php";
include"includes/header.php" ?>

        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a class="list-group-item active ">Media </a>
                <a href="news" class="list-group-item list-group-item-action">News</a>
                <a href="events" class="list-group-item list-group-item-action">Events</a>
                 <a href="links" class="list-group-item list-group-item-action">Important Links</a>
            </div>
        </div>
        <div class="col-md-9" style="padding-top:25px;">

            <div class="row">
<?php

 $test1 = $db->query("SELECT*FROM news WHERE `status` = '1' ORDER BY `id` DESC");
$test1->execute();
 while($resultat1 = $test1->fetch()){
    $lenght=150;
                $description=$resultat1['text'];
                $new_description=substr($description,0,$lenght)."...";
?>
                <h4><?php echo $resultat1['title']; ?></h4>
             <?php echo $resultat1['data']; ?>
                <p class="text-justify" > <?php echo $new_description ?> </p>
                <p class="text-right"><a href="spnews.php?id=<?php echo $resultat1['id']; ?>"> Read More</a></p>

                <hr noshade>
<?php
}
?>
            </div>
        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>