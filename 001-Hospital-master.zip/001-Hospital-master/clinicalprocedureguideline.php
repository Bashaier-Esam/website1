﻿ <?php include"includes/header.php" ?>


				<div class="col-md-3" style="padding-top:25px;">
					<div class="list-group">
						<a href="tqm" class="list-group-item active ">Quality & Safety </a>
						<a href="cebahichapters" class="list-group-item list-group-item-action" >Policies & procedures</a>
						<a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Protocols & Guidelines</a>
						<a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
						<a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
						<a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
					</div>
				</div>

				<div class="col-md-9"  style="padding-top:25px;">

				<div class="row">

					<div class="col-md-3" >
					<div class="btn-group btn-group-justified" role="group" aria-label="...">
                  <!--  <div class="btn-group" role="group">
                   <a href="clinicalprocedureguideline" class="btn btn-primary">Introduction</a>
                     </div>-->
                    <div class="btn-group" role="group">
                     <a href="clinicalchapters" class="btn btn-primary">Policies</a>
                   </div>

                    </div>
					</div>



				<div class="col-md-12" style="padding-top:25px"></div>

				<h3>Introduction </h3><br>
               <p class="text-justify"> SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.</p><br><br>



			</div>
			</div>

	  <div class="col-md-12">
	 <br><br>
	  </div>


       <?php include"includes/footer.php" ?>