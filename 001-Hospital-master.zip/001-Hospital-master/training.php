﻿<?php include"includes/header.php" ?>



        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a href="training" class="list-group-item active ">Training </a>
                <a href="courses" class="list-group-item list-group-item-action">Course</a>

            </div>
        </div>
        <div class="col-md-9">

            <h3>Introduction</h3><br>

            <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>

        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>