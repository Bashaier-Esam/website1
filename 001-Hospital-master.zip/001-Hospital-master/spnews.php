﻿<?php
include"connect.php";
include"includes/header.php" ?>



 `
				<div class="col-md-3" style="padding-top:25px;">
					<div class="list-group">
						<a href="media" class="list-group-item active ">Media </a>
						<a href="news" class="list-group-item list-group-item-action">News</a>
						<a href="events" class="list-group-item list-group-item-action">Events</a>
					</div>
				</div>
				<div class="col-md-9" >

			<div class="row">
<?php
$id=$_GET['id'];
$test1 = $db->query("SELECT*FROM news WHERE id=$id");
$test1->execute();
$resultat1 = $test1->fetch();

?>

		<h3><?php echo $resultat1['title']; ?> </h3>
					<div class="col-md-12" ></div>


				<?php
 $id=$_GET['id'];
 $test2 = $db->query("SELECT*FROM news_picture WHERE news_id=$id");
$test2->execute();
while($resultat2 = $test2->fetch()){

?>
				         	<div class="col-md-12" style="
                             text-align: center;">
							<img class="img-responsive" style=" margin: 0 auto;
                                                               " src="<?php echo $resultat2['link']; ?>" alt="Card image cap"  width="555" height="416"><br>

				           	</div>

	<?php
}
?>

					<div class="col-md-12">
					 <p class="text-justify"><?php echo $resultat1['text']; ?></p>

					</div>





				</div>
			</div>

	  <div class="col-md-12">
	 <br><br>
	  </div>



      <?php include"includes/footer.php" ?>