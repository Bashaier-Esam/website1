<?php
include"connect.php";
include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>


    </div>
</div>

<div class="col-md-9" style="padding-top:25px;">

<?php
 $test1 = $db->query("SELECT*FROM  training_cousesplan ");
$test1->execute();
 while($resultat1 = $test1->fetch()){
?>
    <h4> <?php echo $resultat1['title']; ?>  </h4>


    <li class="list-group-item myli">

        <a href="<?php echo $resultat1['link']; ?> " Click here>
Click Here
        </a>
    </li>




    <hr noshade>

<?php
}
?>

</div>


<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>