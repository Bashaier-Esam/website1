﻿<?php
include"connect.php";
include"includes/header.php" ?>

        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a  class="list-group-item active ">Media </a>
                <a href="news" class="list-group-item list-group-item-action">News</a>
                <a href="events" class="list-group-item list-group-item-action">Events</a>
                 <a href="links" class="list-group-item list-group-item-action">Important Links</a>
            </div>
        </div>
        <div class="col-md-9" style="padding-top:25px;">

            <div class="row">
 <?php

 $test1 = $db->query("SELECT * FROM `events` WHERE `status` = '1' ORDER BY `id` DESC");
$test1->execute();
 while($resultat1 = $test1->fetch()){
?>
                <div class="col-md-4">
                    <div class="card" style="height:100%">
                        <img class="img-responsive" src="<?php echo $resultat1['img']; ?>" alt="Card image cap">
                        <div class="card-body">
                            <a href="spevents.php?id=<?php echo $resultat1['id']; ?>" class="list-group-item "><h4 class="card-title"><?php echo $resultat1['title']; ?></h4></a>
                        </div>
                    </div>
                </div>

               <?php
           }
           ?>

            </div>


        </div>

        <div class="col-md-12">
            <br><br>
        </div>

        <?php include"includes/footer.php" ?>