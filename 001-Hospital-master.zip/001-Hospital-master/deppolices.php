<?php
  include"connect.php";
include"includes/header.php" ?>

        <div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
						<a href="tqm" class="list-group-item active ">Quality & Safety </a>
						<a href="cebahichapters" class="list-group-item list-group-item-action" >Policies & procedures</a>
						<a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Protocols & Guidelines</a>
						<a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
						<a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
						<a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
					</div>
        </div>
        <div class="col-md-9" style="padding-top:25px;">
            <div class="row">
                <div class="col-md-7" >
                    <div class="btn-group btn-group-justified" role="group" aria-label="...">
                     <!--   <div class="btn-group" role="group">
                            <a href="procedur&policy" class="btn btn-primary">Introduction</a>
                        </div>-->
                        <div class="btn-group" role="group">
                           <a href="cebahichapters" class="btn btn-primary">Genral Policies</a>
                        </div>
                         <div class="btn-group" role="group">
                           <a href="deppolices" class="btn btn-primary">Departmental Policies</a>
                       </div>

                    </div>
                </div>

                <br> <br> <br>


<?php
 $test1 = $db->query("SELECT*FROM departmental_policies_chapter");
$test1->execute();
$j=0;
 while($resultat1 = $test1->fetch()){
    $j++;
?>

        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"  >
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <?php echo $resultat1['title']; ?>
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: <?php echo $resultat1['data']; ?></span>  <span class="tab-space"> Review date <?php echo $resultat1['data']; ?></span>
<?php
 $id=$resultat1['id'];
$reqmail = $db->prepare("SELECT*FROM departmental_policies WHERE chapter_id=$id ");
$reqmail ->execute();
$mailexist=$reqmail->rowCount();
if($mailexist > 0 ){
?>
                        <span class="tab-space">
                            <input type="search" id="myInput<?php echo $j ; ?>" onkeyup="search('myInput<?php echo $j ; ?>','myUL<?php echo $j ; ?>','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>

        <?php
    }
    ?>
                        <br><br>



                        <ul id="myUL<?php echo $j ; ?>" >
                         <?php
        $id=$resultat1['id'];
         $test2 = $db->query("SELECT*FROM departmental_policies WHERE chapter_id=$id ORDER BY id DESC LIMIT 300");
$test2->execute();
$i=0;
 while($resultat2 = $test2->fetch()){
    $i++;
?>
                          <div class="row">

                             <div class="col-md-10">

                            <?php
                            if($i<5) {
                                ?>
                            <li class='myli'><a href="<?php echo $resultat2['option_file']; ?>" class="list-group-item "><?php echo $resultat2['title']; ?> <span class="badge">New</span></a></li>
                             <?php
                         }else {
                            ?>
                            <li class='myli'><a href="<?php echo $resultat2['option_file']; ?>" class="list-group-item "><?php echo $resultat2['title']; ?> </a> </li>
                         <?php
                     }
                     ?>

                                </div>
                                <div class="col-md-1">
                                <?php
                                if(!empty($resultat2['option_file'])){
                                    ?>
                                    <li class='myli'>
                                 <a type="button" class="btn btn-sm btn-primary " href="<?php echo $resultat2['option_file']; ?>"  >
                                    <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
                                    </a>

                                    </li>
                                    <?php
                                     }else{

                                     }
                                     ?>
                                </div>

                            </div>
<?php
}
?>




                                </ul>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
    <?php
}
?>

        </div>
    </div>
</div>


<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>