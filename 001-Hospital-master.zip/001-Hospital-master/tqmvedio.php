﻿<?php 
include"connect.php";
include"includes/header.php" ?>


        <div class="col-md-3" style="padding-top:25px;">
      <div class="list-group">
						<a href="tqm" class="list-group-item active ">Quality & Safety </a>
						<a href="cebahichapters" class="list-group-item list-group-item-action" >Policies & procedures</a>
						<a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Protocols & Guidelines</a>
						<a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
						<a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
						<a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
					</div>
        </div>
        <div class="col-md-9" style="padding-top:25px;">
 <?php 

 $test1 = $db->query("SELECT*FROM videos ORDER BY id LIMIT 5 ");
$test1->execute();
 while($resultat1 = $test1->fetch()){
?>
            <h4> <?php echo $resultat1['title']; ?>  </h4>
            <h5> Date : <?php echo $resultat1['data']; ?></h5>
            <br>
            <div class="embed-responsive embed-responsive-16by9">
                <video width="320" height="240" controls>
                    <source src="<?php echo $resultat1['link']; ?>" type="video/mp4">
                </video>

            </div>


            <hr noshade>
<?php
}
?>
            </div>


        </div>


        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>