﻿<?php include"includes/header.php" ?>


        <div class="col-md-3" style="padding-top:25px;">
            <div class="list-group">
                <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
                <a href="departments" class="list-group-item list-group-item-action">Departments</a>
                <a href="centers" class="list-group-item list-group-item-action">Centers</a>
            </div>
        </div>
        <div class="col-md-9">

            <div class="row">

                <h3>Introduction </h3><br>
                <p class="text-justify"> SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                    SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                    SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.Saudi German Hospital - Madinah
                </p>
            </div>

        </div>

        <div class="col-md-12">
            <br><br>
        </div>


        <?php include"includes/footer.php" ?>